from csv import DictReader, DictWriter

import numpy as np

from movie_data import *
from numpy import array
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer
from sklearn.linear_model import SGDClassifier
from sklearn.model_selection import cross_val_score
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.pipeline import Pipeline, FeatureUnion

from scipy.sparse import csr_matrix

kTARGET_FIELD = 'spoiler'
kTEXT_FIELD = 'sentence'


class Feature1(BaseEstimator, TransformerMixin):
    #KEY SPOILER WORDS - may not have as large of an effect as thought
    def __init__(self):
        pass

    def fit(self, examples, y=None):
        return self

    def transform(self, examples, y=None):
        spoilers = ['killed', 'kill', 'died', 'killer', 'dead', '"', 'ends', 
                    'episode', 'victims', 'victim', 'series', 'finale', 'season',
                    'scene', 'represented', 'turned', 'had', 'pushed', 'subverted',
                    'worse', 'discovered'] 
        """
        X = np.zeros((len(examples), len(spoilers)))

        for i, x in enumerate(examples):
            X[i,:] = np.array([x.count(word) for word in spoilers])
        """
        X = np.zeros((len(examples), 1))

        for i, x in enumerate(examples):
            x = x.split(" ")
            x = [a.lower() for a in x]
            for j in spoilers:
                if j in x:
                    X[i] = 1
                else:
                    X[i] = 0
        return csr_matrix(X)

class Feature2(BaseEstimator, TransformerMixin):
    #GENRE - Get from IMBD

    def __init__(self):
        pass

    def fit(self, examples, y=None):
        return self

    def transform(self, examples, y=None):
        genres = ['Mystery', 'Drama', 'Thriller', 'Crime', 'Short',
                  'Sci-Fi', 'Comedy', 'Romance', 'Thriller', 'Action',
                  'Family', 'Adventure', 'Horror']
        pass

class Feature3(BaseEstimator, TransformerMixin):
    #Plot key words
    #not effective - 
    #maybe with an ability to predict the movies one could
    #use plot key words

    def __init__(self, plot_words):
        self.plot_words = plot_words

    def fit(self, examples, y=None):
        return self

    def transform(self, examples, y=None):
        
        X = np.zeros((len(examples), 1))

        for i, x in enumerate(examples):
            words = x.split(" ")
            for i in words:
                if i in self.plot_words:
                     X[i,:] = np.array([1])
                else:
                     X[i,:] = np.array([0])
            X[i,:] = np.array([x.count(word) for word in self.plot_words])

        return csr_matrix(X)

class Feature4(BaseEstimator, TransformerMixin):
    #length

    def __init__(self):
        pass

    def fit(self, examples, y=None):
        return self

    def transform(self, examples, y=None):
        X = np.zeros((len(examples), 1))

        for i, x in enumerate(examples):
            x = x.split(" ")
            sentence_len = len(x)
            if sentence_len > 40:
                X[i] = 1
            else:
                X[i] = 0

        return csr_matrix(X)

if __name__ == "__main__":   
    #imbd movie data 
    imbd_data = Movie_Data()
    imbd_data.clean_keywords()

    # Cast to list to keep it all in memory
    train = list(DictReader(open("../data/spoilers/train.csv", 'r')))
    test = list(DictReader(open("../data/spoilers/test.csv", 'r')))

    labels = []
    for line in train:
        if not line[kTARGET_FIELD] in labels:
            labels.append(line[kTARGET_FIELD])    

    y_train = array(list(labels.index(x[kTARGET_FIELD])
                         for x in train))

    x_train = [x[kTEXT_FIELD] for x in train]
    x_test = [x[kTEXT_FIELD] for x in test]

    pipeline = Pipeline([
        ('features', FeatureUnion([ 
        ('tfidf', TfidfVectorizer()),
        ('feature1', Feature1()),
        ('feature4', Feature4())
        ])),
        ('classifier',  SGDClassifier(loss='log', penalty='l2', shuffle=True))
        ])


    pipeline.fit(x_train, y_train)

    predictions = pipeline.predict(x_test)

    #cross validation scores
    scores = cross_val_score(pipeline, x_train, y_train, cv=5)

    o = DictWriter(open("predictions.csv", 'w'), ["Id", "spoiler"])
    o.writeheader()
    for ii, pp in zip([x['Id'] for x in test], predictions):
        d = {'Id': ii, 'spoiler': labels[pp]}
        o.writerow(d)
 
    print '\n'
    print "Accuracy: %0.2f (+/- %0.2f)" % (scores.mean(), scores.std() * 2)
    print '\n'
    
